package maoda;

public class compareToDemo
{

	public static void main(String[] args)
	{
		System.out.println("ABeb".compareTo("ABfa"));
		System.out.println("ABCd222坏蛋".compareTo("ABCe2222"));
		
		System.out.println("abcd".compareTo("ad "));
//		
//		
		System.out.println("abvvvv".startsWith("b"));
		System.out.println("abvvvv".endsWith("v"));
//		
//		System.out.println(!"cccs".contains("c"));
		
//		System.out.println("+++"+" a b c d e f".trim());
	}

}
