package maoda;

public class TestMain
{

	public static void main(String[] args)
	{
	 HumanPlayer player1= new HumanPlayer();
	 player1.sendMessage(HumanPlayer.MessageTypeWin);

	}

}
