package maoda;

public class StringByteDemo
{

	public static void main(String[] args)
	{
	    byte[] byteArray ={104,101,108,108,111};
		String str6=new String(byteArray);
		System.out.print(str6);

	}

}
