package maoda;
import java.lang.*;

public class IntegerDemo
{

	public static void main(String[] args)
	{
//		Integer int1=new Integer();
		String str2=new String();
		System.out.print("+++"+str2+"+++");
		String str3="";
		System.out.print("+++"+str3+"+++"+(str2==str3));
		String str4="";
		System.out.print(str4==str3);
	}

}
