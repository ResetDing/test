package maoda.RPG;
/**
 * 抽象类可以只是一个空壳，他只是一个概念，抽象的爸爸无作为时，孙子继承爷爷进行实例化
 * @author MAOU
 *
 */
public abstract class LongRangeHero extends Hero
{
	
//	private int attackRange;
//	
//	public LongRangeHero() {
//		super();
//		setName("默认游侠");
//	}
//	
//	public LongRangeHero(long id,String name,int x,int y) {
//		super(id,name);
//		setAttackRange(attackRange);
//		setX(x);
//		setY(y);
//	}
//	
//	
//	public int getAttackRange()
//	{
//		return attackRange;
//	}
//
//	public void setAttackRange(int attackRange)
//	{
//		this.attackRange = attackRange;
//	}
	
	
}
