package maoda.RPG;

public class Assasin extends Hero
{

}
