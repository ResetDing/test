package maoda;

public class hana
{

	public static void main(String[] args)
	{
		int a = 5;
		double b = a++/2;
		System.out.println(b);
		// TODO Auto-generated method stub
		System.out.println("maoda's baby");
		System.out.println("小花吃爆米花");
		 System.out.println("映画見たり、ピアノ弾いたりする");
		 System.out.println("どこか旅行するかな");
	}
}


